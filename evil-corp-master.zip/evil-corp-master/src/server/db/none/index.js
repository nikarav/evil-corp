const connect = () => {};
const controllers = () => {};
const passport = () => {};
const session = () => {};

export default { connect, controllers, passport, session };
