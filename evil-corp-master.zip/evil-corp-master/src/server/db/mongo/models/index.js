export default function loadModels() {
  require('./activity_model');
  require('./administrator_model');
  require('./user_model');
  require('./parent_model');
  require('./provider_model');
  require('./ticket_model');
}
