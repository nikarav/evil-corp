import deserializeUser from './deserializeUser';
import local from './local';

export { deserializeUser, local };

export default {
  deserializeUser,
  local,
};
