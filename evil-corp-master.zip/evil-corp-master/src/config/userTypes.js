export const USER_TYPES = {
  Parent: 'Parent',
  Provider: 'Provider',
  Administrator: 'Administrator'
};

