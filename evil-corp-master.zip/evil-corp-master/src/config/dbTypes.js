export const DB_TYPES = {
  MONGO: 'MONGO',
  NONE: 'NONE'
};

