import { connect } from 'react-redux';
import { getActivities } from '../actions/ActivityShow';
 //import ActivitiesList from '../components/ActivitiesList';


 // const mapStateToProps = (state) => {
 //     return {
 //         postsList: state.ActivityList.postsList
 //     };
 // };
