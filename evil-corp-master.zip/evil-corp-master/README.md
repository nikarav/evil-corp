# evil-corp

## Description

The purpose of this project is the creation of a web platform where parents
will be able to buy tickets for various activities aimed at their children and
providers will be able to promote their activities.

## Team

| Ονοματεπώνυμο          | Α.Μ.    | Email                   |
| :---                   | :---    | :---                    |
| Αδάμης Δημήτριος       | 3113077 | jimadamis95@yahoo.com   |
| Αναστασίου Εμμανουήλ   | 3113078 | el13078@mail.ntua.gr    |
| Βλάχου Βασιλική        | 3113015 | silvia713@msn.com       |
| Δημητρίου Κωνσταντίνος | 3113167 | el13167@central.ntua.gr |
| Καραβασίλης Νικόλαος   | 3113012 | nikarav@hotmail.com     |
| Σωτηρίου Δημήτριος     | 3112059 | el12059@mail.ntua.gr    |

## Software and Technical Requirements

1. [Software and Technical Requirements](./Requirements/Software_Requirements.md)
